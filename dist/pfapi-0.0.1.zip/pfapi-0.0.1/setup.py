from distutils.core import setup
setup(name='pfapi',
      version='0.0.1',
      py_modules=['pfapi'],
      author=['Dimitri Korsch'],
      author_email=['korschdima@gmail.com'],
      url=['http://pageformant.de'],
      )